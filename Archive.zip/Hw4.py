from PIL import Image, ImageDraw
import cv2
from math import pi,sqrt
import numpy as np
from scipy.signal import convolve2d
from skimage import color, data, restoration


img1=cv2.imread('Fig3.tif',0)
img2=cv2.imread('Fig5.7.tif',0)


#def GAUSSIAN,pepper & Salt noises
def noisy(noise_typ,image,s_vs_p):
    if noise_typ == "gauss":
        row,col= image.shape
        mean = 0
        var = 0.1
        sigma = var**0.5
        gauss = np.random.normal(mean,sigma,(row,col))
        gauss = gauss.reshape(row,col)
        noisy = image + gauss
        return noisy
    elif noise_typ == "s&p":
        row,col = image.shape
        s_vs_p = 0.5
        amount = 0.004
        out = np.copy(image)
        # Salt mode
        num_salt = np.ceil(amount * image.size * s_vs_p)
        coords = [np.random.randint(0,i-1,int(num_salt))
                  for i in image.shape]
        out[coords] = 1
                                                              
        # Pepper mode
        num_pepper = np.ceil(image.size * (1. - s_vs_p))
        coords = [np.random.randint(0,i-1,int(num_pepper))
                  for i in image.shape]
        out[coords] = 0
        return out


# 01 --------------

# a + b --- > using Fig3.tif img
def P1():
    rs=int(input("  1.Guassian noise | 2. Pepper & Salt noise "))
    if (rs==1):
        cc=noisy("gauss",img1,0.5)
    if (rs==2):
        cc= noisy("s&p",img1,0.5)

    cv2.imshow("Project 05-01",cc)

# 02  Noise Reduction Using a Median Filter

# a
def median_filter(data, filter_size):
    temp = []
    indexer = filter_size // 2
    data_final = []
    data_final = np.zeros((len(data),len(data[0])))
    for i in range(len(data)):
        for j in range(len(data[0])):
            for z in range(filter_size):
                if i + z - indexer < 0 or i + z - indexer > len(data) - 1:
                    for c in range(filter_size):
                        temp.append(0)
                else:
                    if j + z - indexer < 0 or j + indexer > len(data[0]) - 1:
                        temp.append(0)
                    else:
                        for k in range(filter_size):
                            temp.append(data[i + z - indexer][j + k - indexer])
        
            temp.sort()
            data_final[i][j] = temp[len(temp) // 2]
            temp = []
    return data_final



def p2_1():
    img = Image.open("Fig3.tif").convert("L")
    arr = np.array(img)
    removed_noise = median_filter(arr, 3)
    img = Image.fromarray(removed_noise)
    img.show("Project 2_1")

#b  ----> Fig5.7.tif
def p2_2():
        p21= noisy("s&p",img2,0.2)
        cv2.imshow("Project 05-01",p21)
        p22=noisy("gauss",img2,0.2)
        cv2.imshow("Project 05-01",p22)




# 03 ----- Periodic Noise Reduction

# a  --> 5.14 equation 4.15 f(x, y) = A sin(u0x + v0y)
# b
# c
# d



def p4_1():
# 04 - Parametric Wiener Filter
#     a :
#    Eq. (5.6-11)
#    Gs (u, v)/
#    Hs(u,v) = FN (u,v)
    dst = cv2.GaussianBlur(img2,(13,13),cv2.BORDER_DEFAULT)

#
    cv2.imshow("Take me out",dst)
# b
# c
# d
def p4_4():
    
    from skimage import color, data, restoration

    img2 = color.rgb2gray(data.astronaut())
    from scipy.signal import convolve2d
    psf = np.ones((5, 5)) / 25
    img2 = convolve2d(img2, psf, 'same')
    img2 += 0.1 * img2.std() * np.random.standard_normal(img2.shape)
    deconvolved_img = restoration.unsupervised_wiener(img2, psf)
    cv2.imshow("Deco Image",img2)
#    restoration.wiener(deconvolved_img, psf, balance, reg=None, is_real=True, clip=True)





## Main calling Functions
#P1()
#p2_1()
#p2_2()
#p4_1()
p4_4()

k = cv2.waitKey(0)
if k == 27:         # wait for ESC key to exit
    v2.destroyAllWindows()



